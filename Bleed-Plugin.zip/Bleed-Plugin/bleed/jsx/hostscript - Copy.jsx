function breaking(loc){
    loopAnimation=loc.split("||")[1].split(",")[0];
    loopDuration=loc.split("||")[1].split(",")[1];
    soundFx=loc.split("||")[1].split(",")[2];
    loc=loc.split("||")[0];
    app.activeViewer.setActive();
     

   
    var myComp = app.project.activeItem;
    var oldComp = app.project.activeItem;
    try{obj=myComp.selectedLayers[0];}catch(e){}
    try{bg=myComp.selectedLayers[1];}catch(e){}
   
    //if(myComp.width!=1920 || myComp.height!=1080 )   {alert("Please use full HD composition (1920*1080).");return;} 
     if(myComp instanceof CompItem)   {} else{alert("Please select a composition.");return; }
     if(myComp .selectedLayers.length==0){alert("Select a layer to break it.");return;}

     if(loopAnimation=="true"){
      durationLoop=parseFloat(loopDuration);
      if (isNaN(loopDuration)){alert("loop Duration range is invalid!");return;}
      if (durationLoop<2){alert("2 seconds is required for the loop mode.");return;}
        }
    // if(pieces>=4){alert("You can choose up to three pieces, in this version.");return;}
    ///////////////////////////////////////
/*
    if(myComp.selectedLayers.length==1)obj1=obj.duplicate();
    obj.selected=false;
    obj1.selected=true;
    precomp();
    for (i=1;i<=myComp.layers.length;i++){myComp.layer(i).selected=false;}
    myComp.layer(1).selected=true;

    numLayers=myComp.layers.length;
if (numLayers==3){
    for (i=1;i<=myComp.layers.length;i++){myComp.layer(i).selected=false;}

   
   obj2=myComp.layer(3).duplicate();
   obj2.selected=false;
   myComp.layer(3).selected=true;

   
    precomp();
    for (i=1;i<=myComp.layers.length;i++){myComp.layer(i).selected=false;}
    myComp.layer(1).selected=true;
}
*/
numLayers=myComp.layers.length;
precomp();
app.activeViewer.setActive();
myComp.layer(1).selected=true;
  imageComp=app.project.activeItem.selectedLayers[0];
  placeId=imageComp.source.id;
  
targetFile=new File(loc+"/jsx/bleedLoop.aep");
 
  

  objName=myComp.selectedLayers[0].name;
 
    
    preComp=myComp.layer(1);

    
 
  
    importedFile=targetFile;
  
     importedItem=app.project.importFile(new ImportOptions(importedFile)) ;
    imageCompId= importedItem.item(2).id;
    breakCompId= importedItem.item(1).id;

    preComp.source.parentFolder=importedItem;
    preComp.source.name="Image-Precomped";
  
   importedImage=app.project.itemByID(imageCompId).layers.add(app.project.itemByID(placeId));
   importedImage.moveToEnd();
   try{
   importedImage.transform.scale.setValue([app.project.itemByID(imageCompId).height/importedImage.height*100,app.project.itemByID(imageCompId).height/importedImage.height*100]);
  scaleRate=app.project.itemByID(imageCompId).height/importedImage.height;
   }catch(e){}
   
  
  
  
   importedItem.name="Bleed-"+objName;
   myComp.layer(1).remove();
    bloodLayer=app.project.activeItem.layers.add(importedItem.item(1));
    try{ 
      bloodLayer.transform.scale.setValue([myComp.height/bloodLayer.height*100,myComp.height/bloodLayer.height*100]);
     //scaleRate=myComp.height/bloodLayer.height;
      }catch(e){}


   //importedItem.item(1).openInViewer();
   app.activeViewer.setActive();
   var myComp = app.project.activeItem;





   myComp.time=0;


   myComp.layer(1).selected=true;
   
  


if(loopAnimation=="true"){
  
   particleId= importedItem.item(3).id;

   mapComp=app.project.itemByID(particleId);
            layer1=mapComp.layer(2);
            layer2=mapComp.layer(3);
            layer2.enabled=true;

            
            layer1.startTime=-21.458+durationLoop;
        
            tmpOutPoint=   layer1.outPoint
              layer1.inPoint=0;
             layer1.outPoint=tmpOutPoint;
             layer2.outPoint=tmpOutPoint;

            bitRateLayer_1= layer1.property("ADBE Effect Parade").property(1).property("CC Particle World-0004");
            bitRateLayer_1_keyTimesArray = [0,0.05];
          bitRateLayer_1_valuesArray = [0,1];
            bitRateLayer_1.setValuesAtTimes(bitRateLayer_1_keyTimesArray, bitRateLayer_1_valuesArray);
            

          bitRateLayer_2= layer2.property("ADBE Effect Parade").property(1).property("CC Particle World-0004");
            bitRateLayer_2_keyTimesArray = [0,0.05];
          bitRateLayer_2_valuesArray = [1,0];
            bitRateLayer_2.setValuesAtTimes(bitRateLayer_2_keyTimesArray, bitRateLayer_2_valuesArray);

            myComp.workAreaStart=0;
            myComp.workAreaDuration=durationLoop;
                      layer1.outPoint=durationLoop;
                      layer2.outPoint=durationLoop;

                      }

                      

            if(soundFx=="false"){importedItem.item(5).item(10).remove();}

  }
  
  function checkTrial(){
    alert("In the free trial version, you cannot select more than one piece.\nPlease purchase a license.");return;
  }

  function precomp(){
  
      app.activeViewer.setActive();
     var myComp = app.project.activeItem;
   
     if(myComp instanceof CompItem) {
   
       var myLayers = myComp.selectedLayers;
       if(myLayers.length > 0){
   
         var newInPoint = myLayers[0].inPoint;
         var newOutPoint = myLayers[0].outPoint;
   
         var newCompName = "comp ";
         var layerName = myLayers[0].name;
         if(layerName.length > 26) {
           layerName = layerName.substring(0, 26);
         }
         newCompName += layerName;
   
         var layerIndices = new Array();
         for (var i = 0; i < myLayers.length; i++) {
           layerIndices[layerIndices.length] = myLayers[i].index;
   
           if (myLayers[i].inPoint < newInPoint) newInPoint = myLayers[i].inPoint;
           if (myLayers[i].outPoint > newOutPoint) newOutPoint = myLayers[i].outPoint;
         }
   
         var newComp = myComp.layers.precompose(layerIndices, newCompName+Math.floor(Math.random() * 1000), true );
   
         var preCompLayer = myComp.selectedLayers[0];
         preCompLayer.inPoint = newInPoint;
         preCompLayer.outPoint = newOutPoint;
   
       }else{
          alert("select at least one layer to precompose.");
       }
     }else{
       alert("please select a composition.");
     }
  
   }
   
  
   function btn_MC(){
    if (app.preferences.getPrefAsLong("Main Pref Section", "Pref_SCRIPTING_FILE_NETWORK_SECURITY") != 1)
    {
        alert("Please tick the \"Allow Scripts to Write Files and Access Network\" checkbox if Preferences > General");
        app.executeCommand(2359);
    }
    var os = system.osName;
    if (!os.length)
    {
        os = $.os;
    }
    app_os =  ( os.indexOf("Win") != -1 )  ?  "Win" : "Mac"
    var url = "https://aescripts.com/bleed";
    if ( app_os == "Win" )
    {
        system.callSystem("explorer " + url);
    }
    else
    {
        system.callSystem("open " + url);
    }
    
    }