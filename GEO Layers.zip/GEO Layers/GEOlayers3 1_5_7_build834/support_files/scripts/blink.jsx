//This script lets selected layers blink. Check out their Effect Controls afterwards.
#target AfterEffects
(function(){
    var blink = function(layer, freqVal, ampVal, offVal){
        if(layer instanceof AVLayer || layer instanceof ShapeLayer || layer instanceof TextLayer){
            freqVal = (freqVal==undefined)?0.5:parseFloat(freqVal)
            ampVal = (ampVal==undefined)?20:parseFloat(ampVal)
            offVal = (offVal==undefined)?0:parseFloat(offVal)
            var freq = layer.property("ADBE Effect Parade").addProperty("ADBE Slider Control");
            freq.name = "Blink Frequency";
            freq.property("ADBE Slider Control-0001").setValue(freqVal);
            var amp = layer.property("ADBE Effect Parade").addProperty("ADBE Slider Control");
            amp.name = "Blink Amplitude";
            amp.property("ADBE Slider Control-0001").setValue(ampVal);
            var off = layer.property("ADBE Effect Parade").addProperty("ADBE Slider Control");
            off.name = "Blink Offset";
            off.property("ADBE Slider Control-0001").setValue(offVal);
            var opacity = layer.property("ADBE Transform Group").property("ADBE Opacity");
            if(opacity.numKeys === 0){
                var opacity_keyTimesArray = [layer.containingComp.time, layer.containingComp.time + 0.5];
                var opacity_valuesArray = [0, 100-ampVal];
                opacity.setValuesAtTimes(opacity_keyTimesArray, opacity_valuesArray);
            }
            try {
                opacity.expression = "var sinVal = Math.sin((time-effect(\"Blink Offset\")(1))*effect(\"Blink Frequency\")(1)*Math.PI*2)*effect(\"Blink Amplitude\")(1);\n" +
                "var sinMult = easeOut(value,0,25,0,1);\n" +
                "value+(sinVal*sinMult)";
            } catch (err) {}
        }
    }
    var activeItem = app.project.activeItem;
    app.beginUndoGroup("Blink")
    if(activeItem instanceof CompItem && activeItem.selectedLayers.length){
        for(var l = 0; l < activeItem.selectedLayers.length; l++){
            blink(activeItem.selectedLayers[l],0.5,20,activeItem.time)
        }
    }else{
        alert("Please select at least one layer in your current composition.")
    }
    app.endUndoGroup()
})()
