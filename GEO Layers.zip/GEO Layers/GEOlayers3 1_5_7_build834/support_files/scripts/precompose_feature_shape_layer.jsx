//This script precomposes a shape layer on which a GEOlayers Feature has been drawn.
#target AfterEffects
(function(){
    var utils = geolayers3.utils;
    function replaceAll(str, find, replace) {
        if (str && str.replace) {
            return str.replace(new RegExp(find, 'g'), replace);
        } else {
            return str
        }
    }
    var precompShapeLayer = function(layer){
        if(!(layer instanceof ShapeLayer)) throw new Error("Please select a shape layer to precompose.")
        if(
            layer.property("ADBE Transform Group").property("ADBE Scale").numKeys > 0 ||
            layer.property("ADBE Transform Group").property("ADBE Position").numKeys > 0 ||
            layer.property("ADBE Transform Group").property("ADBE Orientation").numKeys > 0 ||
            layer.property("ADBE Transform Group").property("ADBE Anchor Point").numKeys > 0 
        ) throw new Error("Keyframed transform properties are not supported.")
        app.beginUndoGroup("Precomp Geo Shape 1")
        var sRect = layer.sourceRectAtTime(comp.time, false)
        var preComp = app.project.items.addComp(layer.name + " comp", Math.ceil(sRect.width), Math.ceil(sRect.height), 1, comp.duration, comp.frameRate)
        app.endUndoGroup()
        layer.copyToComp(preComp)
        app.beginUndoGroup("Precomp Geo Shape 2")
        var newL = preComp.layer(1)
        utils.getLayerPropsInComp(preComp, function(prop){
            return prop.expression && prop.expression.length > 0
        }).forEach(function(prop){
            prop.expression = replaceAll(prop.expression, "thisComp.", "comp('" + layer.containingComp.name + "').")
        })
        newL.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0,0,0])
        newL.property("ADBE Transform Group").property("ADBE Scale").setValue([100,100,100])
        newL.property("ADBE Transform Group").property("ADBE Position").setValue([0,0,0])
        newL.property("ADBE Transform Group").property("ADBE Orientation").setValue([0,0,0])

        var preCompLayer = comp.layers.add(preComp, comp.duration);
        preCompLayer.startTime = layer.startTime;
        preCompLayer.inPoint = layer.inPoint;
        preCompLayer.outPoint = layer.outPoint;
        preCompLayer.threeDLayer = true;
        preCompLayer.collapseTransformation = true;
        preCompLayer.moveBefore(layer);
        preCompLayer.parent = layer.parent
        preCompLayer.property("ADBE Transform Group").property("ADBE Anchor Point").setValue(layer.property("ADBE Transform Group").property("ADBE Anchor Point").value)
        preCompLayer.property("ADBE Transform Group").property("ADBE Scale").setValue(layer.property("ADBE Transform Group").property("ADBE Scale").value)
        preCompLayer.property("ADBE Transform Group").property("ADBE Position").dimensionsSeparated = false
        preCompLayer.property("ADBE Transform Group").property("ADBE Position").setValue(layer.property("ADBE Transform Group").property("ADBE Position").value)
        preCompLayer.property("ADBE Transform Group").property("ADBE Orientation").setValue(layer.property("ADBE Transform Group").property("ADBE Orientation").value)
        layer.remove()
        app.endUndoGroup()
    }
    try{
        var comp = app.project.activeItem;
        if(!(comp instanceof CompItem)) throw new Error("Please select a shape layer to precompose.")
        for(var i = 0; i < comp.selectedLayers.length; i++){
            var layer = comp.selectedLayers[i];
            precompShapeLayer(layer)
        }
    }catch(e){
        alert(e.message)
    }
})()