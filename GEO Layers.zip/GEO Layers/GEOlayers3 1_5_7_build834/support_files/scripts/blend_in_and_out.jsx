//This script blends a layer in or out at playhead time according to its current opacity. 
#target AfterEffects
(function(){
    var options = {
        duration: 0.4, // blend duration
        snapToFrame: true // no keyframes in between frames
    }
    function applyEasing(property, keyTimesArray, easeInArray, easeOutArray, keyInterpolationArray) {
        var easeIn, easeOut, easeIn0, easeOut0, easeIn1, easeOut1, easeIn2, easeOut2;
        for (var i = 0, il = keyTimesArray.length; i < il; i ++) {
            var keyIndex = property.nearestKeyIndex(keyTimesArray[i])
            if (property.propertyValueType === PropertyValueType.TwoD) {
                easeIn0 = new KeyframeEase(easeInArray[0][i][0], easeInArray[1][i][0]);
                easeOut0 = new KeyframeEase(easeOutArray[0][i][0], easeOutArray[1][i][0]);
                easeIn1 = new KeyframeEase(easeInArray[0][i][1], easeInArray[1][i][1]);
                easeOut1 = new KeyframeEase(easeOutArray[0][i][1], easeOutArray[1][i][1]);
                property.setTemporalEaseAtKey(keyIndex, [easeIn0, easeIn1], [easeOut0, easeOut1]);
            } else if (property.propertyValueType === PropertyValueType.ThreeD) {
                easeIn0 = new KeyframeEase(easeInArray[0][i][0], easeInArray[1][i][0]);
                easeOut0 = new KeyframeEase(easeOutArray[0][i][0], easeOutArray[1][i][0]);
                easeIn1 = new KeyframeEase(easeInArray[0][i][1], easeInArray[1][i][1]);
                easeOut1 = new KeyframeEase(easeOutArray[0][i][1], easeOutArray[1][i][1]);
                easeIn2 = new KeyframeEase(easeInArray[0][i][2], easeInArray[1][i][2]);
                easeOut2 = new KeyframeEase(easeOutArray[0][i][2], easeOutArray[1][i][2]);
                property.setTemporalEaseAtKey(keyIndex, [easeIn0, easeIn1, easeIn2], [easeOut0, easeOut1, easeOut2]);
            } else {
                easeIn = new KeyframeEase(easeInArray[0][i], easeInArray[1][i]);
                easeOut = new KeyframeEase(easeOutArray[0][i], easeOutArray[1][i]);
                if (keyInterpolationArray[1][i] !== KeyframeInterpolationType.HOLD) {
                    property.setTemporalEaseAtKey(keyIndex, [easeIn], [easeOut]);
                } else {
                    property.setTemporalEaseAtKey(keyIndex, [easeIn]);
                }
            }
            property.setInterpolationTypeAtKey(keyIndex, keyInterpolationArray[0][i], keyInterpolationArray[1][i]);
        }
    }
    function getMaxKeyVal(property){
        var maxVal = -Infinity;
        for(var i = 1; i <= property.numKeys; i++){
            maxVal = Math.max(maxVal, property.keyValue(i))
        }
        return maxVal
    }
    var blendLayer = function(layer, options){
        var time = layer.containingComp.time;
        var dur = options && options.duration || 0.4;
        if(options && options.snapToFrame){
            dur = Math.round(dur / layer.containingComp.frameDuration) * layer.containingComp.frameDuration
        }
        var opacity = layer.property("ADBE Transform Group").property("ADBE Opacity");
        var curVal = opacity.value;
        var blendIn = opacity.numKeys < 2 ? true : !(curVal > 0)
        var opacity_keyTimesArray = [time,time + dur];
        var opacity_valuesArray = blendIn ? [0,curVal || getMaxKeyVal(opacity)] : [curVal || 100,0];
        opacity.setValuesAtTimes(opacity_keyTimesArray, opacity_valuesArray);
        var opacity_easeInSpeedArray = [0,0];
        var opacity_easeInInfluArray = [20,60];
        var opacity_easeOutSpeedArray = [0,0];
        var opacity_easeOutInfluArray = [20,60];
        var opacity_keyInInterpolationType = [KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER];
        var opacity_keyOutInterpolationType = [KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER];
        applyEasing(opacity, opacity_keyTimesArray, [opacity_easeInSpeedArray, opacity_easeInInfluArray], [opacity_easeOutSpeedArray, opacity_easeOutInfluArray], [opacity_keyInInterpolationType, opacity_keyOutInterpolationType]);
		if(opacity.keyValue(1) === 0){
            layer.inPoint = opacity.keyTime(1)
        }
        if(blendIn && layer.outPoint < time){
            layer.outPoint = layer.containingComp.duration
        }
        if(opacity.keyValue(opacity.numKeys) === 0){
            layer.outPoint = opacity.keyTime(opacity.numKeys)
        }
        layer.selected = true;
    }
    var handleLayer = function(layer){
        var oldLocked = layer.locked;
        layer.locked = false;
        blendLayer(layer, options)
        layer.locked = oldLocked
    }

    if(!geolayers3){alert("Please launch GEOlayers 3 and try again.")}
    var activeComp = geolayers3.utils.getActiveComp()
    if(activeComp){
        var layers = geolayers3.utils.getSelectedLayersFromComp(activeComp).filter(function(layer){
            return geolayers3.utils.isTextLayer(layer) || geolayers3.utils.isAVLayer(layer) || geolayers3.utils.isShapeLayer(layer)
        })
        if(layers.length){
            app.beginUndoGroup("Blend Layer")
            geolayers3.utils.getLayersFromComp(geolayers3.utils.deselectLayer)
            layers.forEach(handleLayer)
            app.endUndoGroup()
        }else{
            alert("Please select at least one AV, Text or Shape Layer.")
        }
    }else{
        alert("Please select a composition.")
    }
})()

