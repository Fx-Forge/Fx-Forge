//This script staggers your selected layers in time. Higher Layer index first. Note that the time between the selected layers' in points is used to calculate the time offset.
#target AfterEffects
(function() {
    var useWorkAreaTimeSpan = false;
    var snapToFrame = true;
    var snapTimeToFrame = function(comp, time) {
        var compFps = 1 / comp.frameDuration
        return Math.round(time * compFps) / compFps
    }
    var getNewInPoint = function(fromTime, toTime, type, numLayers, layerNr) {
        switch (type) {
            case "random":
                if (layerNr == 0) {
                    return fromTime
                } else if (layerNr == numLayers - 1) {
                    return toTime
                } else {
                    return fromTime + Math.random() * (toTime - fromTime)
                }
                return
                break;
            case "\\":
                return fromTime + layerNr * ((toTime - fromTime) / (numLayers - 1))
                break;
            case "/":
                return toTime - layerNr * ((toTime - fromTime) / (numLayers - 1))
                break;
            case "|":
                return fromTime
                break;
        }
    }
    var moveInPoints = function(type) {
        var activeComp = app.project.activeItem
        var fromTime, toTime, curLayer, curStartTime, curInPoint, curDuration, newInPoint, newStartTime
        var selectedLayers = [];
        app.beginUndoGroup("move in Points")
        fromTime = null
        toTime = null
        selectedLayers = [];
        if (activeComp instanceof CompItem) {
            for (var i = 1; i <= activeComp.numLayers; i++) {
                var curLayer = activeComp.layer(i)
                if (curLayer.selected) {
                    if (fromTime == null) {
                        fromTime = curLayer.inPoint
                    } else {
                        fromTime = Math.min(fromTime, curLayer.inPoint)
                    }
                    if (toTime == null) {
                        toTime = curLayer.inPoint
                    } else {
                        toTime = Math.max(toTime, curLayer.inPoint)
                    }
                    selectedLayers.push(curLayer)
                }
            }
            writeLn(String(fromTime / activeComp.frameDuration) + "-" + String(toTime / activeComp.frameDuration))
            if (useWorkAreaTimeSpan) {
                fromTime = activeComp.workAreaStart
                toTime = activeComp.workAreaStart + activeComp.workAreaDuration
            }
            if (toTime <= fromTime) {
                toTime = fromTime + (selectedLayers.length - 1) * activeComp.frameDuration;
            }
            for (var i = 0; i < selectedLayers.length; i++) {
                curLayer = selectedLayers[i];
                curStartTime = curLayer.startTime;
                curInPoint = curLayer.inPoint;
                curDuration = curLayer.outPoint - curInPoint;
                newInPoint = getNewInPoint(fromTime, toTime, type, selectedLayers.length, i);
                if (snapToFrame) {
                    newInPoint = snapTimeToFrame(activeComp, newInPoint)
                };
                newStartTime = curStartTime + (newInPoint - curInPoint);
                if (newStartTime || newStartTime == 0) {
                    curLayer.startTime = newStartTime;
                    curLayer.inPoint = newInPoint;
                    curLayer.outPoint = newInPoint + curDuration;
                }
            }
        }
        app.endUndoGroup()
    }

    moveInPoints("/");
})()
