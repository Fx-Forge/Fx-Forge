//This script draws a Shape Layer onto an Mapcomp that visualizes the View of another Mapcomp.
#target AfterEffects
(function(){

    function createViewShapeLayer(anchorLayer, refMapcomp){
        app.beginUndoGroup("create view shape layer")
        var mapcompName = refMapcomp.name
        var zoomView = anchorLayer.containingComp.layers.addShape();
        zoomView.name = "View of Mapcomp '" + mapcompName + "'";
        zoomView.threeDLayer = true;
        var zoomViewGrp = zoomView.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        zoomViewGrp.name = "View";
        var viewPathGrp = zoomViewGrp.property(2).addProperty("ADBE Vector Shape - Group");
        viewPathGrp.name = "View Path";
        var zoomViewPath = viewPathGrp.property("ADBE Vector Shape");
        var zoomViewPath_newShape = new Shape();
        zoomViewPath_newShape.vertices = [[0, 0], [0, 0], [0, 0], [0, 0]];
        zoomViewPath_newShape.closed = true;
        zoomViewPath.setValue(zoomViewPath_newShape);
        var strokeGrp = zoomViewGrp.property(2).addProperty("ADBE Vector Graphic - Stroke");
        strokeGrp.name = "Stroke 1";
        strokeGrp.property("ADBE Vector Stroke Width").setValue(4);
        strokeGrp.property("ADBE Vector Stroke Line Cap").setValue(2);
        strokeGrp.property("ADBE Vector Stroke Line Join").setValue(3);
        zoomView.parent = anchorLayer.parent;
        zoomView.property("ADBE Transform Group").property("ADBE Orientation").setValue([0,0,0]);
        zoomView.property("ADBE Transform Group").property("ADBE Position").dimensionsSeparated = false
        zoomView.property("ADBE Transform Group").property("ADBE Position").setValue([0,0,0]);
        zoomView.property("ADBE Transform Group").property("ADBE Scale").setValue([100,100,100]);
        try {
            zoomViewGrp.property(2).property(1).property("ADBE Vector Shape").expression = "//GEOlayers 3 expression" + "\n" +
                "var c = comp(\"" + mapcompName + "\");" + "\n" + 
                "var mp = c.layer(\"MapPivot\");" + "\n" + 
                "var c2 = thisLayer.parent.source;" + "\n" + 
                "var mp2 = c2.layer(\"MapPivot\");" + "\n" + 
                "var p1 = mp2.toComp(mp.fromCompToSurface([0,0]))" + "\n" + 
                "var p2 = mp2.toComp(mp.fromCompToSurface([c.width,0]))" + "\n" + 
                "var p3 = mp2.toComp(mp.fromCompToSurface([c.width,c.height]))" + "\n" + 
                "var p4 = mp2.toComp(mp.fromCompToSurface([0,c.height]))" + "\n" + 
                "createPath([[p1[0],p1[1]],[p2[0],p2[1]],[p3[0],p3[1]],[p4[0],p4[1]]], [], [], true)";
        } catch (err) {}
        app.endUndoGroup()
    }

    var mapcomps = geolayers3.getMapcomps();
    if(mapcomps.length >= 2){
    geolayers3.modalActions(mapcomps.map(function(mapcomp){
        return mapcomp.name
    }), function(err, index){
        if(index !== undefined){
            var selectedMapcomp = mapcomps.splice(index,1)[0];
            geolayers3.modalActions(mapcomps.map(function(mapcomp){
                return mapcomp.name
            }), function(err, index){
                if(index !== undefined){
                    var refMapcomp = mapcomps[index]
                    createViewShapeLayer(geolayers3.getMapcompAnchor(selectedMapcomp), refMapcomp)
                }
            },{title:"Select Reference Mapcomp", message:"Please select a Mapcomp whose view will be drawn."})
        }
    },{title:"Select Mapcomp", message:"Please select a Mapcomp to draw anothers view on."})
    }else{
        alert("You need to have at least 2 Mapcomps in your project.")
    }
})()