//This script adds a dynamic Scale Bar to your containing composition.
#target AfterEffects
(function() {

    function createMapscale(mapcomp, alignment) {
        app.beginUndoGroup("create Scale Bar")
        var mapcompLayer = geolayers3.getMapcompAnchor(mapcomp).parent;
        var comp = mapcompLayer.containingComp;

        var mapscale = comp.layers.addText("1 km");
        mapscale.name = "Scale Bar Text";
        mapscale.moveToBeginning();
        var mapscale_TextProp = mapscale.property("ADBE Text Properties").property("ADBE Text Document");
        var mapscale_TextDocument = mapscale_TextProp.value;
        mapscale_TextDocument.font = "Verdana-Italic";
        mapscale_TextDocument.fontSize = 30;
        mapscale_TextDocument.applyFill = true;
        mapscale_TextDocument.fillColor = [0, 0, 0];
        mapscale_TextDocument.applyStroke = false;
        mapscale_TextDocument.justification = ParagraphJustification[alignment>0.25?(alignment<0.75?"CENTER_JUSTIFY":"LEFT_JUSTIFY"):"RIGHT_JUSTIFY"];
        mapscale_TextDocument.tracking = 0;
        if (parseFloat(app.version) >= 13.2) {
            mapscale_TextDocument.verticalScale = 1;
            mapscale_TextDocument.horizontalScale = 1;
            mapscale_TextDocument.baselineShift = 0;
            mapscale_TextDocument.tsume = 0;
        }
        if (parseFloat(app.version) >= 13.6) {
            mapscale_TextDocument.autoLeading = true;
        }
        mapscale_TextProp.setValue(mapscale_TextDocument);
        mapscale.property("ADBE Transform Group").property("ADBE Position").dimensionsSeparated = false
        mapscale.property("ADBE Transform Group").property("ADBE Position").setValue([0, -8, 0]);
        mapscale.selected = false;

        var mapscale1 = comp.layers.addShape();
        mapscale1.name = "Scale Bar";
        mapscale1.moveToBeginning();
        mapscale1.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        mapscale1.property("ADBE Root Vectors Group").property(1).name = "Scale";
        mapscale1.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Group");
        mapscale1.property("ADBE Root Vectors Group").property(1).property(2).property(1).name = "Shape";
        var mapscale1Pfad = mapscale1.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Shape");
        var mapscale1Pfad_newShape = new Shape();
        mapscale1Pfad_newShape.vertices = [
            [0, 0]
        ];
        mapscale1Pfad_newShape.closed = false;
        mapscale1Pfad.setValue(mapscale1Pfad_newShape);
        mapscale1.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Stroke");
        mapscale1.property("ADBE Root Vectors Group").property(1).property(2).property(2).name = "Contur";
        mapscale1.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Stroke Color").setValue([0, 0, 0, 1]);
        mapscale1.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Stroke Width").setValue(3);
        mapscale1.property("ADBE Effect Parade").addProperty("ADBE Point Control");
        mapscale1.property("ADBE Effect Parade").property(1).name = "Size";
        mapscale1.property("ADBE Effect Parade").property(1).property("ADBE Point Control-0001").setValue([200, 10]);
		mapscale1.property("ADBE Effect Parade").addProperty("ADBE Checkbox Control");
		mapscale1.property("ADBE Effect Parade").property(2).name = "Fixed Size";
        mapscale1.property("ADBE Effect Parade").property(2).property("ADBE Checkbox Control-0001").setValue(0);
		mapscale1.property("ADBE Effect Parade").addProperty("ADBE Checkbox Control");
		mapscale1.property("ADBE Effect Parade").property(3).name = "Miles";
		mapscale1.property("ADBE Effect Parade").property(3).property("ADBE Checkbox Control-0001").setValue(0);
        mapscale1.property("ADBE Transform Group").property("ADBE Position").setValue([comp.width * 0.05 + (comp.width * (1 - alignment)) * 0.9, comp.height * 0.9, 0]);
        mapscale1.selected = true;
        mapscale.setParentWithJump(mapscale1);
        try {
            mapscale.property("ADBE Text Properties").property("ADBE Text Document").expression = "//GEOlayers 3 expression" + "\n" + 
				"var mapcompName = \"" + mapcomp.name + "\";" + "\n" +
				"var barSize = thisLayer.hasParent?thisLayer.parent.effect(\"Size\")(1)[0]:thisComp.width;" + "\n" + 
				"var useMiles = thisLayer.hasParent?thisLayer.parent.effect(\"Miles\")(1).value:false;" + "\n" + 
				"var fixedBarSize = thisLayer.hasParent?thisLayer.parent.effect(\"Fixed Size\")(1).value:false;" + "\n" + 
				"var r = 40075.016686;" + "\n" + 
				"if(!useMiles){" + "\n" + 
				"	var units = [\"km\", \"m\"];" + "\n" + 
				"	var unitMults = [1,1000];" + "\n" + 
				"	var useComma = true;" + "\n" + 
				"}else{" + "\n" + 
				"	var units = [\"mi\", \"yd\"];" + "\n" + 
				"	var unitMults = [0.621371,1760];" + "\n" + 
				"	var useComma = false;" + "\n" + 
				"};" + "\n" + 
				"var getDistBar = function(){" + "\n" + 
				"	var mapPivot = comp(mapcompName).layer(\"MapPivot\");" + "\n" + 
				"	var y = mapPivot.transform.anchorPoint.value[1];" + "\n" + 
				"	var s = mapPivot.transform.scale.value[1];" + "\n" + 
				"	var mapSize = Math.pow(2,18);" + "\n" + 
				"	var y = 0.5 - (Math.max(0,Math.min(y,mapSize)) / mapSize);" + "\n" + 
				"    var lat = 90 - 360 * Math.atan(Math.exp(-y * 2 * Math.PI)) / Math.PI;" + "\n" + 
				"	var zoom = Math.log(s*mapSize/512/100)/Math.log(2);" + "\n" + 
				"	var distPx = r/512 * Math.cos(degreesToRadians(lat)) / Math.pow(2,zoom);" + "\n" + 
				"	return distPx * barSize" + "\n" + 
				"}" + "\n" + 
                "var straightValue = function(val){" + "\n" + 
				"	var vLength = val.toFixed(0).length;" + "\n" + 
				"	var rVal = Math.pow(10, vLength-1);" + "\n" + 
				"	return Math.round(val/rVal)*rVal;" + "\n" + 
				"}" + "\n" + 
				"var distBar = getDistBar();" + "\n" + 
				"var distBarUnit = distBar * unitMults[0];" + "\n" + 
				"if(!fixedBarSize){" + "\n" + 
				"	if(distBarUnit < 1){" + "\n" + 
				"		out = straightValue(distBarUnit * unitMults[1]) + \" \" + units[1];" + "\n" + 
				"	}else{" + "\n" + 
				"		out = straightValue(distBarUnit) + \" \" + units[0];" + "\n" + 
				"	}" + "\n" + 
				"}else{" + "\n" + 
				"	if(distBarUnit < 1){" + "\n" + 
				"		out = Math.round(distBarUnit * unitMults[1]) + \" \" + units[1];" + "\n" + 
				"	}else if(distBarUnit < 10){" + "\n" + 
				"		var out = distBarUnit.toFixed(1) + \" \" + units[0];" + "\n" + 
				"		if(useComma){" + "\n" + 
				"			out = out.replace(\".\", \",\")" + "\n" + 
				"		};" + "\n" + 
				"	}else{" + "\n" + 
				"		out = Math.round(distBarUnit) + \" \" + units[0]" + "\n" + 
				"	}" + "\n" + 
				"}" + "\n" + 
				"out;";
        } catch (err) {}
        try {
            mapscale1.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Shape").expression = "//GEOlayers 3 expression" + "\n" + 
                "var mapcompName = \"" + mapcomp.name + "\";" + "\n" +
				"var alignment = " + alignment + ";" + "\n" + 
				"var size = effect(\"Size\")(1).value;" + "\n" + 
				"var x = size[0];" + "\n" + 
				"var y = size[1];" + "\n" + 
				"var barSize = x;" + "\n" + 
				"var miles = thisLayer.effect(\"Miles\")(1).value;" + "\n" + 
				"var fixedBarSize = thisLayer.effect(\"Fixed Size\")(1).value;" + "\n" + 
				"var r = 40075.016686;" + "\n" + 
				"if(!miles){" + "\n" + 
				"	var units = [\"km\", \"m\"];" + "\n" + 
				"	var unitMults = [1,1000];" + "\n" + 
				"	var useComma = true;" + "\n" + 
				"}else{" + "\n" + 
				"	var units = [\"mi\", \"yd\"];" + "\n" + 
				"	var unitMults = [0.621371,1760];" + "\n" + 
				"	var useComma = false;" + "\n" + 
				"};" + "\n" + 
				"var getDistBar = function(){" + "\n" + 
				"	var mapPivot = comp(mapcompName).layer(\"MapPivot\");" + "\n" + 
				"	var y = mapPivot.transform.anchorPoint.value[1];" + "\n" + 
				"	var s = mapPivot.transform.scale.value[1];" + "\n" + 
				"	var mapSize = Math.pow(2,18);" + "\n" + 
				"	var y = 0.5 - (Math.max(0,Math.min(y,mapSize)) / mapSize);" + "\n" + 
				"    var lat = 90 - 360 * Math.atan(Math.exp(-y * 2 * Math.PI)) / Math.PI;" + "\n" + 
				"	var zoom = Math.log(s*mapSize/512/100)/Math.log(2);" + "\n" + 
				"	var distPx = r/512 * Math.cos(degreesToRadians(lat)) / Math.pow(2,zoom);" + "\n" + 
				"	return distPx * barSize" + "\n" + 
				"}" + "\n" + 
                "var straightValue = function(val){" + "\n" + 
				"	var vLength = val.toFixed(0).length;" + "\n" + 
				"	var rVal = Math.pow(10, vLength-1);" + "\n" + 
				"	return Math.round(val/rVal)*rVal;" + "\n" + 
				"}" + "\n" + 
				"var distBar = getDistBar();" + "\n" + 
				"var distBarUnit = distBar * unitMults[0];" + "\n" + 
				"if(!fixedBarSize){" + "\n" + 
				"	if(distBarUnit < 1){" + "\n" + 
				"		x = x*straightValue(distBarUnit * unitMults[1])/(distBarUnit * unitMults[1]);" + "\n" + 
				"	}else{" + "\n" + 
				"		x = x*straightValue(distBarUnit)/distBarUnit;" + "\n" + 
				"	}" + "\n" + 
				"}" + "\n" + 
                "var alignmentDiff = alignment - 1;" + "\n" + 
                "var points = [[x*alignmentDiff,0],[x*alignment,0]];" + "\n" + 
                "if(y !== 0){" + "\n" + 
                "    points.push([points[1][0],y])" + "\n" + 
                "    points = [[points[0][0],y]].concat(points)" + "\n" + 
                "}" + "\n" + 
                "createPath(points,[],[],false);";
        } catch (err) {}
        app.endUndoGroup()
    }
    var selectAlignment = function(mapcomp){
        geolayers3.modalActions(["Right", "Center", "Left"], function(err, index) {
            if (index !== undefined) {
                createMapscale(mapcomp, index * 0.5 || 0)
            }
        }, {
            title: "Alignment",
            message: "Please select a where to align your scale bar."
        })
    }
    var mapcomps = geolayers3.getMapcomps();
    if (mapcomps.length >= 2) {
        geolayers3.modalActions(mapcomps.map(function(mapcomp) {
            return mapcomp.name
        }), function(err, index) {
            if (index !== undefined) {
                var selectedMapcomp = mapcomps.splice(index, 1)[0];
                selectAlignment(selectedMapcomp)
            }
        }, {
            title: "Select Mapcomp",
            message: "Please select a Mapcomp to add a scale bar."
        })
    } else if (mapcomps.length == 1) {
        selectAlignment(mapcomps[0])
    } else {
        alert("You need to have at least one Mapcomp in your project.")
    }
})()