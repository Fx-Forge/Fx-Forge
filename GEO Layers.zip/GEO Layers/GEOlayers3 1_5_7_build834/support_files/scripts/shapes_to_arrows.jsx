//This script transforms paths on a Shape Layer to animated Arrows.
#target AfterEffects
(function() {
    try{
        geolayers3.shapesToArrows(app.project && app.project.activeItem, {
            startAniDur: 0.8,
			trimStart: 0,
			trimEnd: 100,
			trimOffset: 0,
			width: 30,
			headSize: 100,
			taper: 80,
			dashWidth: 80,
			dashSize: 20,
			dashGap:20,
			dashSpeed: 50,
			onlyDashes: false
        })
    }catch(e){
        alert(e.message)
    }
})()