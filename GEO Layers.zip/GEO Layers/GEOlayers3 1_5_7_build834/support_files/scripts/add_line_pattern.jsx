//This script adds a venetian blinds effect to selected shape or text layers to let them appear in a line pattern. 
#target AfterEffects
(function(){
    var options = {
        lineWidth: 5, // width of the lines in px
        offset: 5, // offset between lines in px
        angle: 80, // line angle 0° to 360° 
    }
    var addLinePattern = function(layer, options){
        var effName1 = options && options.effName1 || "Line Pattern";
        var curEff, effRemoved
        ([effName1]).forEach(function(effName){
            while(curEff = layer.property("ADBE Effect Parade").property(effName)){
                effRemoved = true
                curEff.remove()
            }
        })
        if(!effRemoved){
            var lineWidth = options && options.lineWidth || 5;
            var angle = options && options.angle || 0;
            var offset = options && options.offset || 5;
            var width = lineWidth + offset
            var completion = 100 - (lineWidth / width * 100);
            var eff = layer.property("ADBE Effect Parade").addProperty("ADBE Venetian Blinds");
            eff.name = effName1;
            eff.property("ADBE Venetian Blinds-0001").setValue(completion);
            eff.property("ADBE Venetian Blinds-0002").setValue(angle);
            eff.property("ADBE Venetian Blinds-0003").setValue(width);
        }
        layer.selected = true;
    }
    var handleLayer = function(layer){
        var oldLocked = layer.locked;
        layer.locked = false;
        addLinePattern(layer, options)
        layer.locked = oldLocked
    }

    if(!geolayers3){alert("Please launch GEOlayers 3 and try again.")}
    var activeComp = geolayers3.utils.getActiveComp()
    if(activeComp){
        var shapeLayers = geolayers3.utils.getSelectedLayersFromComp(activeComp).filter(function(layer){
            return geolayers3.utils.isTextLayer(layer) || geolayers3.utils.isShapeLayer(layer)
        })
        if(shapeLayers.length){
            app.beginUndoGroup("Apply Line Pattern to Layer")
            geolayers3.utils.getLayersFromComp(geolayers3.utils.deselectLayer)
            shapeLayers.forEach(handleLayer)
            app.endUndoGroup()
        }else{
            alert("Please select at least one Text or Shape Layer.")
        }
    }else{
        alert("Please select a composition.")
    }
})()