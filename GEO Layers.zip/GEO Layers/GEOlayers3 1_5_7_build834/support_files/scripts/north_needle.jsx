//This script adds a dynamic North Needle to your containing composition.
#target AfterEffects
(function() {
    function createNorthNeedle(mapcomp, alignment) {
        app.beginUndoGroup("create North Needle")
        var mapcompLayer = geolayers3.getMapcompAnchor(mapcomp).parent;
        var comp = mapcompLayer.containingComp;
        var northNeedle = comp.layers.addShape();
		northNeedle.name = "North Needle";
		northNeedle.moveToBeginning();
		northNeedle.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
		northNeedle.property("ADBE Root Vectors Group").property(1).name = "Needle";
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Group");
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(1).name = "North";
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).addProperty("ADBE Vector Shape - Star");
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(1).name = "North";
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(1).property("ADBE Vector Star Points").setValue(3);
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(1).property("ADBE Vector Star Position").setValue([0,-7.5]);
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(1).property("ADBE Vector Star Inner Radius").setValue(7.5);
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(1).property("ADBE Vector Star Outer Radius").setValue(15);
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).addProperty("ADBE Vector Graphic - Fill");
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(2).name = "Fill 1";
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(2).property("ADBE Vector Fill Color").setValue([1,1,1,1]);
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Group");
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(2).name = "South";
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).addProperty("ADBE Vector Shape - Star");
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(1).name = "South";
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(1).property("ADBE Vector Star Points").setValue(3);
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(1).property("ADBE Vector Star Position").setValue([0,7.5]);
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(1).property("ADBE Vector Star Rotation").setValue(180);
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(1).property("ADBE Vector Star Inner Radius").setValue(7.5);
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(1).property("ADBE Vector Star Outer Radius").setValue(15);
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).addProperty("ADBE Vector Graphic - Fill");
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(2).name = "Fill 1";
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(2).property("ADBE Vector Fill Color").setValue([0,0,0,1]);
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Stroke");
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(3).name = "Stroke 1";
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Stroke Color").setValue([0,0,0,1]);
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Stroke Width").setValue(3);
		northNeedle.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Stroke Line Join").setValue(2);
		northNeedle.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
		northNeedle.property("ADBE Root Vectors Group").property(2).name = "Ring";
		northNeedle.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Shape - Ellipse");
		northNeedle.property("ADBE Root Vectors Group").property(2).property(2).property(1).name = "Ellipse Path 1";
		northNeedle.property("ADBE Root Vectors Group").property(2).property(2).property(1).property("ADBE Vector Ellipse Size").setValue([55,55]);
		northNeedle.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Graphic - Stroke");
		northNeedle.property("ADBE Root Vectors Group").property(2).property(2).property(2).name = "Stroke 1";
		northNeedle.property("ADBE Root Vectors Group").property(2).property(2).property(2).property("ADBE Vector Stroke Color").setValue([0,0,0,1]);
		northNeedle.property("ADBE Root Vectors Group").property(2).property(2).property(2).property("ADBE Vector Stroke Width").setValue(3);
        northNeedle.property("ADBE Transform Group").property("ADBE Position").dimensionsSeparated = false
        northNeedle.property("ADBE Transform Group").property("ADBE Position").setValue([comp.width * 0.05 + (comp.width * (1 - alignment)) * 0.9 + (alignment < 0.5 ? -25 : (alignment > 0.5 ? 25 : 0)), comp.height * 0.83, 0]);
		northNeedle.property("ADBE Transform Group").property("ADBE Rotate Z").setValue(0);
		northNeedle.selected = false;
		try {
			northNeedle.property("ADBE Transform Group").property("ADBE Rotate Z").expression = "//GEOlayers 3 expression" + "\n" + 
				"" + "\n" + 
				"var mapcompName = \"" + mapcomp.name + "\";" + "\n" + 
				"" + "\n" + 
				"var mapPivot = comp(mapcompName).layer(\"MapPivot\");" + "\n" + 
				"" + "\n" + 
				"mapPivot.transform.orientation.value[2]";
		} catch (err) {}
        app.endUndoGroup()
    }
    var selectAlignment = function(mapcomp){
        geolayers3.modalActions(["Right", "Center", "Left"], function(err, index) {
            if (index !== undefined) {
                createNorthNeedle(mapcomp, index * 0.5 || 0)
            }
        }, {
            title: "Alignment",
            message: "Please select a where to align your north needle."
        })
    }
    var mapcomps = geolayers3.getMapcomps();
    if (mapcomps.length >= 2) {
        geolayers3.modalActions(mapcomps.map(function(mapcomp) {
            return mapcomp.name
        }), function(err, index) {
            if (index !== undefined) {
                var selectedMapcomp = mapcomps.splice(index, 1)[0];
                selectAlignment(selectedMapcomp)
            }
        }, {
            title: "Select Mapcomp",
            message: "Please select a Mapcomp to add a north needle."
        })
    } else if (mapcomps.length == 1) {
        selectAlignment(mapcomps[0])
    } else {
        alert("You need to have at least one Mapcomp in your project.")
    }
})()