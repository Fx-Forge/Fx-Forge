var mapcompName = "{{mapcompName}}";
var shapeAnchorName = "{{shapeAnchorName}}";
var latPropName = "{{latPropName}}";
var lonPropName = "{{lonPropName}}";
var heightPropName = "{{heightPropName}}";
var pixelOffsetPropName = "{{pixelOffsetPropName}}";
var positionProgressPropName = "{{positionProgressPropName}}";
var mapSize = {{globalMapSize}};
var scaleFactor = {{scaleFactor}};

var Clip = function(n, minValue, maxValue) {
        return Math.min(Math.max(n, minValue), maxValue);
}
var LatToPixelY = function(latitude){
    var min_lat= -85.05112878;
    var max_lat= 85.05112878;
    latitude = Clip(latitude, min_lat, max_lat);
    var sinLatitude = Math.sin(latitude * Math.PI / 180);
    var y = 0.5 - Math.log((1 + sinLatitude) / (1 - sinLatitude)) / (4 * Math.PI);
    var pixelY = y * mapSize /*+ 0.5*/;
    pixelY = Clip(pixelY, 0, mapSize - 1);
    return pixelY
}
var LonToPixelX = function(longitude){
    var x = (longitude + 180) / 360;
    var pixelX = x * mapSize /*+ 0.5*/;
    return pixelX
}

try{
    var pixelOffset = effect(pixelOffsetPropName).param(1).value;
}catch(e){
    var pixelOffset = [0,0,0];
}
var latProp = effect(latPropName).param(1);
var lonProp = effect(lonPropName).param(1);
var pxHeightProp = effect(heightPropName).param(1);
try{
    var progressEff = effect(positionProgressPropName);
    var progressProp = progressEff.param(1);
}catch(e){
    var progressProp = null
}
if(progressProp && progressEff.active && (latProp.numKeys > 1 || lonProp.numKeys > 1 || pxHeightProp.numKeys > 1)){
	var tMin = Math.min(latProp.numKeys?latProp.key(1).time:Infinity, Math.min(lonProp.numKeys?lonProp.key(1).time:Infinity, pxHeightProp.numKeys?pxHeightProp.key(1).time:Infinity));
	var tMax = Math.max(latProp.numKeys?latProp.key(latProp.numKeys).time:-Infinity, Math.max(lonProp.numKeys?lonProp.key(lonProp.numKeys).time:-Infinity, pxHeightProp.numKeys?pxHeightProp.key(pxHeightProp.numKeys).time:-Infinity));
	var lat = latProp.valueAtTime(linear(progressProp.value,0,100,tMin, tMax))
	var lon = lonProp.valueAtTime(linear(progressProp.value,0,100,tMin, tMax))
	var pxHeight = pxHeightProp.valueAtTime(linear(progressProp.value,0,100,tMin, tMax))
}else{
    var lat = latProp.value;
	var lon = lonProp.value;
	var pxHeight = pxHeightProp.value;
}
var shapeAnchorLayer = thisComp.layer(shapeAnchorName)

var posInLayer = [LonToPixelX(lon) + pixelOffset[0]*scaleFactor, LatToPixelY(lat) + pixelOffset[1]*scaleFactor, (-pxHeight * scaleFactor) - pixelOffset[2]*100/shapeAnchorLayer.transform.scale[1]]
if(thisLayer.hasParent){
    pos = thisLayer.parent.fromCompToSurface(shapeAnchorLayer.toComp(posInLayer))
}else{
    if (value.length == 2) {
        pos = shapeAnchorLayer.toComp(posInLayer)
    } else {
        pos = shapeAnchorLayer.toWorld(posInLayer)
    }
}

pos
