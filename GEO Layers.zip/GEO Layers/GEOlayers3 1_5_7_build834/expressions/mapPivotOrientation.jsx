var containingCompName = "{{containingCompName}}";
var mapcompLayerName = "{{mapcompLayerName}}";
var maxPitchDegree = {{maxPitchDegree}};
var linkMapcompName = {{linkMapcompName}};

if(linkMapcompName){
    var linkMapcompPivot = null;
    var linkMapcompRotation = null;
    try{
        linkMapcompPivot = comp(linkMapcompName).layer("{{mapPivotLayerName}}")
        linkMapcompRotation = effect("{{mapPivotLinkMapcompRotationName}}").param(1).value
    }catch(e){}
}
if(linkMapcompPivot && linkMapcompRotation){
    linkMapcompPivot.transform.orientation.value
}else{

    var controlLayer = comp(containingCompName).layer(mapcompLayerName);
    var diffTime = controlLayer.startTime;
    var myTime = time + diffTime;
    var BearingEff = controlLayer.effect("Bearing").param(1);
    var PitchEff = controlLayer.effect("Pitch").param(1);

    [-Math.max(-maxPitchDegree,Math.min(maxPitchDegree, PitchEff.valueAtTime(myTime))),0,BearingEff.valueAtTime(myTime)]
}