if(hasParent){
    parent.source.layer("MapPivot").transform.anchorPoint.valueAtTime(time-parent.startTime)
}else{
    value
}
