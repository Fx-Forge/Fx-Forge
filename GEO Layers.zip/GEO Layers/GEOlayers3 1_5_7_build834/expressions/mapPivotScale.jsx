var mapSize = {{globalMapSize}};
var globalInterpolationTileSize = {{globalInterpolationTileSize}};
var globalMaxZoom = {{globalMaxZoom}};
var containingCompName = "{{containingCompName}}";
var mapcompLayerName = "{{mapcompLayerName}}";
var linkMapcompName = {{linkMapcompName}};

if(linkMapcompName){
    var linkMapcompPivot = null;
    var linkMapcompOffset = null;
    var linkMapcompZoom = null;
    try{
        linkMapcompPivot = comp(linkMapcompName).layer("{{mapPivotLayerName}}")
        linkMapcompOffset = effect("{{mapPivotLinkMapcompOffsetName}}").param(1)
        linkMapcompZoom = effect("{{mapPivotLinkMapcompZoomName}}").param(1).value
    }catch(e){}
}
if(linkMapcompPivot && linkMapcompZoom){
    if(linkMapcompOffset && linkMapcompOffset[2] != 0){
        var scaleVal = Math.pow(2,Math.log(linkMapcompPivot.transform.scale.value[1])/Math.log(2) + linkMapcompOffset[2]);
        [scaleVal, scaleVal, scaleVal]
    }else{
        linkMapcompPivot.transform.scale.value
    }
}else{

    var controlLayer = comp(containingCompName).layer(mapcompLayerName);
    var diffTime = controlLayer.startTime;
    var myTime = time + diffTime;
    var ZoomEff = controlLayer.effect("Zoom").param(1);

    var scaleVal = 100*Math.pow(2,Math.max(0,Math.min(globalMaxZoom,ZoomEff.valueAtTime(myTime))))/mapSize*globalInterpolationTileSize;
    [scaleVal,scaleVal,scaleVal]
}