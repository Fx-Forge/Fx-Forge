if(hasParent){
    parent.source.layer("MapPivot").transform.orientation.valueAtTime(time-parent.startTime)
}else{
    value
}
