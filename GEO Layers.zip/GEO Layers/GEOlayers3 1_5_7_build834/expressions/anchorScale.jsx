if(hasParent){
    parent.source.layer("MapPivot").transform.scale.valueAtTime(time-parent.startTime)
}else{
    value
}
