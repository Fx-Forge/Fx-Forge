var pxHeight = 0;
var scaleFactor = 1;
var scaledHeight = pxHeight*scaleFactor;
thisComp.layer("{{mapPivotLayerName}}").toComp([{{apx}}, {{apy}}, scaledHeight && thisComp.layer("{{mapPivotLayerName}}").transform.scale[1]/100*scaledHeight || 0])