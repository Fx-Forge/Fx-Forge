var shapeAnchorName = "{{shapeAnchorName}}";
var scaleWithMapPropName = "{{scaleWithMapPropName}}";
var scaleFactor = {{scaleFactor}};

try{var scaleWithMap = effect(scaleWithMapPropName).param(1).value}catch(e){var scaleWithMap = false}
var shapeAnchorLayer = thisComp.layer(shapeAnchorName)
if(scaleWithMap){
    if(thisLayer.hasParent && thisLayer.parent == shapeAnchorLayer){
        var scaleV = value
    }else{
        var s = shapeAnchorLayer.transform.scale[0] * scaleFactor/100
        if(value.length > 2){
            var scaleV = [value[0]*s,value[1]*s,value[2]*s]
        }else{
            var scaleV = [value[0]*s,value[1]*s]
        }
    }
}else{
    if(thisLayer.hasParent && thisLayer.parent == shapeAnchorLayer){
        var s = shapeAnchorLayer.transform.scale[0] * scaleFactor/100
        if(value.length > 2){
            var scaleV = [value[0]/s,value[1]/s,value[2]/s]
        }else{
            var scaleV = [value[0]/s,value[1]/s]
        }
    }else{
        var scaleV = value
    }
}

scaleV