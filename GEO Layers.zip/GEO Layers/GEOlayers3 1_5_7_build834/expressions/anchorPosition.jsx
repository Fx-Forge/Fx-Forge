if(hasParent){
    [parent.source.width/2, parent.source.height/2, value[2]]
}else{
    value
}