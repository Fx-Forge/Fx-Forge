obtained file https://cdnjs.cloudflare.com/ajax/libs/ajv/5.2.3/ajv.min.js from here:
https://cdnjs.com/libraries/ajv
